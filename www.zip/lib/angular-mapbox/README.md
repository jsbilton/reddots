# angular-mapbox

Install with `bower install angular-mapbox`.

Please see the [documentation](http://licyeus.github.io/angular-mapbox) for usage.
